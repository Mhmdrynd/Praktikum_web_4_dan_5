function Form() {
    var x = document.forms['myForm']['fname'].value;
    var z = document.forms['myForm']['pass'].value;
    if (x =="Mhmdrynd", z == "Bucin123") {
        alert('Login Success!');
        return true;
    }
    
   
    else {
        alert('Username atau password salah');
        return false;
    }
}
